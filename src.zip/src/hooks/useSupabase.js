import { supabase } from '../services/supabase';

export const useSupabase = () => {
  return supabase;
};
